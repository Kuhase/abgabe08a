StringStack: Stack wird erstellt.
Methoden:
isEmpty() --> zeigt an, ob Stack empty ist
push() --> bef�llt Stack
pop() --> l�scht Elemente aus Stack

Testen: Methoden werden getestet
Stack wird mit Elementen bef�llt, die oberesten vier werden wieder gel�scht und ausgegeben.

by Jessica Lipp